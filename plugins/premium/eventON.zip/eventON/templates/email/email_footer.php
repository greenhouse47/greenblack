<?php
/**
 * Email Footer
 *
 * @author 		EventON
 * @package 	EventON/Templates/Emails
 * @version     0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

		</div>
    </div>
</body>
</html>