<?php
	/*
	Plugin Name: Basix Twitter Feed
	Plugin URI: http://www.themeforest.net/user/artivity
	Description: Displays a Twitter feed from a specified Twitter account.
	Author: Artivity
	Version: 1.0.0
	Author URI: http://www.themeforest.net/user/artivity
	*/

	/* Twitter API 1.1 Function ------------------------------------------------------ */

	if (!function_exists('basix_get_twitter_timeline')) {
		function basix_get_twitter_timeline($twitter_id, $max_tweets, $consumer_key, $consumer_secret, $user_token, $user_secret, $tweet_cache) {
			$transient_name = 'new_twitter_cache_' . strtolower($twitter_id);
			$twitter_cache  = get_transient($transient_name);
			$currentFile = __FILE__;
			$currentFolder = dirname($currentFile);
			require_once($currentFolder . '/authentication/tmhOAuth.php');

			$tmhOAuth = new tmhOAuth(array(
				'consumer_key'    => $consumer_key,
				'consumer_secret' => $consumer_secret,
				'user_token'      => $user_token,
				'user_secret'     => $user_secret
			));

			$twitter_data = $tmhOAuth->request('GET', $tmhOAuth->url('1.1/statuses/user_timeline'), array(
				'screen_name'      => $twitter_id,
				'count'            => $max_tweets,
				'include_rts'      => TRUE,
				'include_entities' => TRUE
			));

			/* this will store in transient */
			$data          = $tmhOAuth->response['response'];
			$twitter_array = json_decode($data, TRUE);

			/* cache time */
			if (!$twitter_cache) {
				if (!$tweet_cache) {
					$tweet_cache = '0';
				}
				set_transient($transient_name, $twitter_array, $tweet_cache * 60);
			}

			/* Delete Cache */
			if ($tweet_cache == "0") {
				echo 'Deleting Twitter Cache...';
				delete_transient($transient_name);
				delete_option($transient_name);
			}

			$twitter = '';

			if ($twitter_cache):
				foreach ($twitter_cache as $tweet) {
					$pubDate         = $tweet['created_at'];
					$tweet_text      = $tweet['text'];
					$tweet_permalink = $tweet['id_str'];

					$today          = time();
					$time           = substr($pubDate, 11, 5);
					$day            = substr($pubDate, 0, 3);
					$date           = substr($pubDate, 7, 4);
					$month          = substr($pubDate, 4, 3);
					$year           = substr($pubDate, 25, 5);
					$english_suffix = date('jS', strtotime(preg_replace('/\s+/', ' ', $pubDate)));
					$full_month     = date('F', strtotime($pubDate));

					#pre-defined tags
					$default   = $full_month . $date . $year;
					$full_date = $day . $date . $month . $year;
					$ddmmyy    = $date . $month . $year;
					$mmyy      = $month . $year;
					$mmddyy    = $month . $date . $year;
					$ddmm      = $date . $month;

					#Time difference
					$timeDiff = dateDiff($today, $pubDate, 1);

					# Turn URLs into links
					$tweet_text = preg_replace('@(https?://([-\w\.]+)+(:\d+)?(/([\w/_\./-]*(\?\S+)?)?)?)@', '<a target="blank" title="$1" href="$1">$1</a>', $tweet_text);

					#Turn hashtags into links
					$tweet_text = preg_replace('/#([0-9a-zA-Z_-]+)/', "<a target='blank' title='$1' href=\"http://twitter.com/search?q=%23$1\">#$1</a>", $tweet_text);

					#Turn @replies into links
					$tweet_text = preg_replace("/@([0-9a-zA-Z_-]+)/", "<a target='blank' title='$1' href=\"http://twitter.com/$1\">@$1</a>", $tweet_text);

					$twitter .= "<li><div class='twitter-text'><p>" . $tweet_text . "</p></div>";

					$when = '';

					$twitter .= '<span class="tweet-time"><a target="_blank" class="time" href="https://twitter.com/' . $twitter_id . '/status/' . $tweet_permalink . '">';

					$twitter .= $timeDiff . "&nbsp;ago";

					$twitter .= "</a></span></li>"; //end of List

				} // end of foreach

				/* store the tweets in options string */
				update_option($transient_name, $twitter);

			endif;

			echo stripcslashes(get_option($transient_name));

		}
	}


	/* Date Function ----------------------------------------------------------------- */

	if (!function_exists('dateDiff')) {
		function dateDiff($time1, $time2, $precision = 6) {
			if (!is_int($time1)) {
				$time1 = strtotime($time1);
			}
			if (!is_int($time2)) {
				$time2 = strtotime($time2);
			}
			if ($time1 > $time2) {
				$ttime = $time1;
				$time1 = $time2;
				$time2 = $ttime;
			}
			$intervals = array(
				'year',
				'month',
				'day',
				'hour',
				'minute',
				'second'
			);
			$diffs     = array();
			foreach ($intervals as $interval) {
				$diffs[$interval] = 0;
				$ttime            = strtotime("+1 " . $interval, $time1);
				while ($time2 >= $ttime) {
					$time1 = $ttime;
					$diffs[$interval]++;
					$ttime = strtotime("+1 " . $interval, $time1);
				}
			}
			$count = 0;
			$times = array();
			foreach ($diffs as $interval => $value) {
				if ($count >= $precision) {
					break;
				}
				if ($value > 0) {
					if ($value != 1) {
						$interval .= "s";
					}
					$times[] = $value . " " . $interval;
					$count++;
				}
			}
			return implode(", ", $times);
		}
	}


	/* Widget Class ------------------------------------------------------------------ */

	class basix_twitter_widget extends WP_Widget {

		/* Constructor ---------------------------------------------------------------- */

		function basix_twitter_widget() {
			parent::WP_Widget(FALSE, $name = __('Basix Twitter Widget', 'basix-td'), array(
				'description' => __('Display tweets from specified username.', 'basix-td')
			));
		}


		/* Widget --------------------------------------------------------------------- */

		function widget($args, $instance) {

			extract($args);

			/* Get the options into variables */
			$twitter_consumer_key    = isset($instance['twitter_consumer_key']) ? $instance['twitter_consumer_key'] : "";
			$twitter_consumer_secret = isset($instance['twitter_consumer_secret']) ? $instance['twitter_consumer_secret'] : "";
			$twitter_user_token      = isset($instance['twitter_user_token']) ? $instance['twitter_user_token'] : "";
			$twitter_user_secret     = isset($instance['twitter_user_secret']) ? $instance['twitter_user_secret'] : "";
			$twitter_username        = isset($instance['twitter_username']) ? $instance['twitter_username'] : "";
			$twitter_count           = isset($instance['twitter_count']) ? $instance['twitter_count'] : "";
			$tweet_cache             = isset($instance['tweet_cache']) ? $instance['tweet_cache'] : "60";
			$widget_title            = empty($instance['title']) ? __('Latest Tweets', 'basix-td') : apply_filters('widget_title', $instance['title']);

			/* Unique ID */
			$unique_id = $args['widget_id'];


			echo $before_widget;
			echo $before_title . $widget_title . $after_title;

			/* Front End Output */
			?>
			<ul class="twitter-feed" id="twitter_update_list_<?php echo $unique_id; ?>">
				<?php echo basix_get_twitter_timeline(
					$twitter_username,
					$twitter_count,
					$twitter_consumer_key,
					$twitter_consumer_secret,
					$twitter_user_token,
					$twitter_user_secret,
					$tweet_cache
				);
				?>
			</ul>
			<?php
			echo $after_widget;
		}

		/* Update & Save -------------------------------------------------------------- */

		function update($new_instance, $old_instance) {
			return $new_instance;
		}

		/* Widget Form ---------------------------------------------------------------- */

		function form($instance) {
			/* Get the options into variables */
			$twitter_consumer_key    = isset($instance['twitter_consumer_key']) ? $instance['twitter_consumer_key'] : "";
			$twitter_consumer_secret = isset($instance['twitter_consumer_secret']) ? $instance['twitter_consumer_secret'] : "";
			$twitter_user_token      = isset($instance['twitter_user_token']) ? $instance['twitter_user_token'] : "";
			$twitter_user_secret     = isset($instance['twitter_user_secret']) ? $instance['twitter_user_secret'] : "";
			$twitter_username        = isset($instance['twitter_username']) ? $instance['twitter_username'] : "";
			$twitter_count           = isset($instance['twitter_count']) ? $instance['twitter_count'] : "";
			$tweet_cache             = isset($instance['tweet_cache']) ? $instance['tweet_cache'] : "60";
			$widget_title            = empty($instance['title']) ? __('Twitter', 'basix-td') : apply_filters('widget_title', $instance['title']);
			?>
			<p>
				<label for="<?php echo $this->get_field_id('title'); ?>"><?php echo __("Widget Title:", 'basix-td'); ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $widget_title; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_consumer_key'); ?>"><?php echo __('Twitter Consumer Key:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_consumer_key'); ?>" name="<?php echo $this->get_field_name('twitter_consumer_key'); ?>" value="<?php echo $twitter_consumer_key; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_consumer_secret'); ?>"><?php echo __('Twitter Consumer Secret:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_consumer_secret'); ?>" name="<?php echo $this->get_field_name('twitter_consumer_secret'); ?>" value="<?php echo $twitter_consumer_secret; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_user_token'); ?>"><?php echo __('Twitter User Token:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_user_token'); ?>" name="<?php echo $this->get_field_name('twitter_user_token'); ?>" value="<?php echo $twitter_user_token; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_user_secret'); ?>"><?php echo __('Twitter User Secret:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_user_secret'); ?>" name="<?php echo $this->get_field_name('twitter_user_secret'); ?>" value="<?php echo $twitter_user_secret; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_username'); ?>"><?php echo __('Twitter ID:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_username'); ?>" name="<?php echo $this->get_field_name('twitter_username'); ?>" value="<?php echo $twitter_username; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('twitter_count'); ?>"><?php echo __('Number Of Tweets:', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('twitter_count'); ?>" name="<?php echo $this->get_field_name('twitter_count'); ?>" value="<?php echo $twitter_count; ?>"/>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('tweet_cache'); ?>"><?php echo __('Tweet Cache Time (minutes):', 'basix-td') ?></label>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('tweet_cache'); ?>" name="<?php echo $this->get_field_name('tweet_cache'); ?>" value="<?php echo $tweet_cache; ?>"/>
				<span style="font-size: 0.9em; color: #888888;">Set to '0' and refresh your site to remove the cache.
				</span>
			</p>
		<?php
		}
	}

	add_action('widgets_init', 'register_basix_twitter_widget');
	function register_basix_twitter_widget() {
		register_widget('basix_twitter_widget');
	}

?>