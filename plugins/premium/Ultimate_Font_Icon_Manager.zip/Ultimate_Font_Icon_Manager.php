<?php
	/*
		Plugin Name: Font Icon Manager for Visual Composer
		Plugin URI: https://brainstormforce.com/demos/ultimate/
		Author: Brainstorm Force
		Author URI: https://www.brainstormforce.com
		Version: 1.0.1
		Description: A font icon manager for Visual Composer. Allows use of font icons downloaded from icomoon.io.
		Text Domain: smile
	*/
	if(!defined('__ULTIMATE_ROOT__')){
		define('__ULTIMATE_ROOT__', dirname(__FILE__));
	}
	if(!class_exists('Ultimate_Font_Icon_Manager'))
	{
		add_action('admin_init','init_addons');
		function init_addons()
		{
			$required_vc = '3.7';
			if(defined('WPB_VC_VERSION')){
				if( version_compare( $required_vc, WPB_VC_VERSION, '>' )){
					add_action( 'admin_notices', 'admin_notice_for_version');
				}
				} else {
				add_action( 'admin_notices', 'admin_notice_for_vc_activation');
			}
		}// end init_addons
		function admin_notice_for_version()
		{
			echo '<div class="updated"><p>The <strong>Font Icon Manager for Visual Composer</strong> plugin requires <strong>Visual Composer</strong> version 3.7.2 or greater.</p></div>';
		}
		function admin_notice_for_vc_activation()
		{
			echo '<div class="updated"><p>The <strong>Font Icon Manager for Visual Composer</strong> plugin requires <strong>Visual Composer</strong> Plugin installed and activated.</p></div>';
		}
		// plugin class
		class Ultimate_Font_Icon_Manager
		{
			var $paths = array();
			var $module_dir;
			var $assets_js;
			var $assets_css;
			var $vc_template_dir;
			var $vc_dest_dir;
			function __construct()
			{
				//add_action( 'init', array($this,'init_addons'));
				$this->vc_template_dir = plugin_dir_path( __FILE__ ).'vc_templates/';
				$this->vc_dest_dir = get_template_directory().'/vc_templates/';
				$this->module_dir = plugin_dir_path( __FILE__ ).'modules/';
				$this->assets_js = plugins_url('assets/js/',__FILE__);
				$this->assets_css = plugins_url('assets/css/',__FILE__);
				$this->paths = wp_upload_dir();
				$this->paths['fonts'] 	= 'font_icons';
				$this->paths['fonturl'] = trailingslashit($this->paths['baseurl']).$this->paths['fonts'];
				add_action('init',array($this,'VC_init'));
				add_action('admin_enqueue_scripts',array($this,'vc_admin_scripts'));
				add_action('wp_enqueue_scripts',array($this,'vc_front_scripts'));

				//add_action('admin_init', array($this, 'VC_move_templates'));
			}// end constructor
			function VC_init()
			{
				// activate addons one by one from modules directory
				foreach(glob($this->module_dir."/*.php") as $module)
				{
					require_once($module);
				}
			}// end VC_init
			function vc_admin_scripts()
			{
				// enqueue css files on backend
				wp_enqueue_style('vc-icon-manager',$this->assets_css.'icon-manager.css');
				wp_enqueue_script('vc-inline-editor',$this->assets_js.'vc-inline-editor.js',array('vc_inline_custom_view_js'),'1.5',true);
				$fonts = get_option('font_icons');
				if(is_array($fonts))
				{
					foreach($fonts as $font => $info)
					{
						if(strpos($info['style'], 'http://' ) !== false) {
							wp_enqueue_style('bsf-'.$font,$info['style']);
							} else {
							wp_enqueue_style('bsf-'.$font,trailingslashit($this->paths['fonturl']).$info['style']);
						}
					}
				}
			}// end VC_admin_scripts
			function vc_front_scripts()
			{
				$fonts = get_option('font_icons');
				if(is_array($fonts))
				{
					foreach($fonts as $font => $info)
					{
						$style_url = $info['style'];
						if(strpos($style_url, 'http://' ) !== false) {
							wp_enqueue_style('bsf-'.$font,$info['style']);
							} else {
							wp_enqueue_style('bsf-'.$font,trailingslashit($this->paths['fonturl']).$info['style']);
						}
					}
				}
			}// end aio_front_scripts
			function VC_move_templates()
			{
				// Make destination directory
				if (!is_dir($this->vc_dest_dir)) {
					wp_mkdir_p($this->vc_dest_dir);
				}
				@chmod($this->vc_dest_dir,0777);
				foreach(glob($this->vc_template_dir.'*') as $file)
				{
					$new_file = basename($file);
					@copy($file,$this->vc_dest_dir.$new_file);
				}
			}// end VC_move_templates
		}//end class
		new Ultimate_Font_Icon_Manager;
	}// end class check