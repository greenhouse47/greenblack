<?php

namespace OpenCloud\Common\Exceptions;

class NetworkUrlError extends \Exception {}
