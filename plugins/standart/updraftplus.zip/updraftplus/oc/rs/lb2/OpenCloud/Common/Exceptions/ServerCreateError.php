<?php

namespace OpenCloud\Common\Exceptions;

class ServerCreateError extends \Exception {}
