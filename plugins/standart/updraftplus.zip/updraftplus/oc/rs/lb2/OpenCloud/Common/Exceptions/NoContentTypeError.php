<?php

namespace OpenCloud\Common\Exceptions;

class NoContentTypeError extends \Exception {}
