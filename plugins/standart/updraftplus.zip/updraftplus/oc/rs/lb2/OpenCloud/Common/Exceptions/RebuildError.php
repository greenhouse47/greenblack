<?php

namespace OpenCloud\Common\Exceptions;

class RebuildError extends \Exception {}
