<?php

namespace OpenCloud\Common\Exceptions;

class JsonError extends \Exception {}
