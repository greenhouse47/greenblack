<?php

namespace OpenCloud\Common\Exceptions;

class AttributeError extends \Exception {}
