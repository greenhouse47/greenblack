<?php

namespace OpenCloud\Common\Exceptions;

class DeleteError extends \Exception {}
