<?php

namespace OpenCloud\Common\Exceptions;

class DocumentError extends \Exception {}
