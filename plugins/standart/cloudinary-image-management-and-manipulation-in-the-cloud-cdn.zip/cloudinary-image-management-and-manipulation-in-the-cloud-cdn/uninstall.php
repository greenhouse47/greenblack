<?php    
    delete_option( 'cloudinary_version' );
    delete_option( 'cloudinary_url' );
?>