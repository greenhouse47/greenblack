

<?php echo $cloudinary_plugin->init_media_lib_integration($cloudinary_plugin->prepare_cloudinary_media_lib_url("wp_gallery"), true); ?>
